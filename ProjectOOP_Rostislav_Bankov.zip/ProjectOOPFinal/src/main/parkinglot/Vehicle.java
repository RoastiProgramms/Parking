package main.parkinglot;

public interface Vehicle {

    public String getColor();

    public String getRegistrationNumber();

    public String getAbonamentInfo();

}
